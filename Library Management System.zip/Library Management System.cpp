#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

// ================== BOOK CLASS ==================
class Book {
private:
    int bookID;
    char title[50];
    char author[50];
    bool issued;

public:
    // Input book details
    void input() {
        cout << "\nEnter Book ID: ";
        cin >> bookID;
        cin.ignore();

        cout << "Enter Book Title: ";
        cin.getline(title, 50);

        cout << "Enter Author Name: ";
        cin.getline(author, 50);

        issued = false;
    }

    // Display book details
    void display() const {
        cout << left << setw(10) << bookID
             << setw(25) << title
             << setw(20) << author
             << setw(10) << (issued ? "Issued" : "Available")
             << endl;
    }

    // Getters
    int getID() const { return bookID; }
    bool isIssued() const { return issued; }

    // Actions
    void issue() { issued = true; }
    void giveBack() { issued = false; }
};

// ================== FUNCTION DECLARATIONS ==================
void addBook();
void displayBooks();
void issueBook();
void returnBook();
void menu();

// ================== ADD BOOK ==================
void addBook() {
    Book b;
    ofstream file("library.dat", ios::binary | ios::app);

    if (!file) {
        cout << "Error opening file!\n";
        return;
    }

    b.input();
    file.write((char*)&b, sizeof(b));

    file.close();
    cout << "✅ Book added successfully!\n";
}

// ================== DISPLAY BOOKS ==================
void displayBooks() {
    Book b;
    ifstream file("library.dat", ios::binary);

    if (!file) {
        cout << "No records found!\n";
        return;
    }

    cout << "\n-------------------------------------------------------------\n";
    cout << left << setw(10) << "ID"
         << setw(25) << "Title"
         << setw(20) << "Author"
         << setw(10) << "Status" << endl;
    cout << "-------------------------------------------------------------\n";

    while (file.read((char*)&b, sizeof(b))) {
        b.display();
    }

    file.close();
}

// ================== ISSUE BOOK ==================
void issueBook() {
    int id;
    cout << "\nEnter Book ID to issue: ";
    cin >> id;

    fstream file("library.dat", ios::binary | ios::in | ios::out);

    if (!file) {
        cout << "File not found!\n";
        return;
    }

    Book b;
    bool found = false;

    while (file.read((char*)&b, sizeof(b))) {
        if (b.getID() == id) {
            found = true;

            if (!b.isIssued()) {
                b.issue();

                file.seekp(-sizeof(b), ios::cur);
                file.write((char*)&b, sizeof(b));

                cout << "✅ Book issued successfully!\n";
            } else {
                cout << "⚠️ Book already issued!\n";
            }
            break;
        }
    }

    if (!found)
        cout << "❌ Book not found!\n";

    file.close();
}

// ================== RETURN BOOK ==================
void returnBook() {
    int id;
    cout << "\nEnter Book ID to return: ";
    cin >> id;

    fstream file("library.dat", ios::binary | ios::in | ios::out);

    if (!file) {
        cout << "File not found!\n";
        return;
    }

    Book b;
    bool found = false;

    while (file.read((char*)&b, sizeof(b))) {
        if (b.getID() == id) {
            found = true;

            if (b.isIssued()) {
                b.giveBack();

                file.seekp(-sizeof(b), ios::cur);
                file.write((char*)&b, sizeof(b));

                cout << "✅ Book returned successfully!\n";
            } else {
                cout << "⚠️ Book was not issued!\n";
            }
            break;
        }
    }

    if (!found)
        cout << "❌ Book not found!\n";

    file.close();
}

// ================== MENU ==================
void menu() {
    cout << "\n========== LIBRARY MANAGEMENT SYSTEM ==========\n";
    cout << "1. Add Book\n";
    cout << "2. Display Books\n";
    cout << "3. Issue Book\n";
    cout << "4. Return Book\n";
    cout << "5. Exit\n";
    cout << "Enter your choice: ";
}

// ================== MAIN FUNCTION ==================
int main() {
    int choice;

    do {
        menu();
        cin >> choice;

        switch (choice) {
            case 1: addBook(); break;
            case 2: displayBooks(); break;
            case 3: issueBook(); break;
            case 4: returnBook(); break;
            case 5: cout << "Thank you! Exiting...\n"; break;
            default: cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 5);

    return 0;
}